# MUSTAFA FX AUDIO — prototype 0.1

## What this prototype does
- Lets you select a local audio file and play it inside the app.
- Attaches Android audio effects to this app's own playback session: Equalizer, BassBoost, PresetReverb and Virtualizer.
- Includes simple room/hall presets and sliders.

## Important limitation
This prototype does **not** modify YouTube Music, Spotify, Instagram or all phone audio. Android apps cannot generally attach their audio effects to another app's private audio session. YouTube Music may also disallow playback capture. System-wide processing usually requires OEM/system audio-effect support, a compatible privileged audio effect, or root-level integration.

The app currently uses Android's built-in `PresetReverb`; a true configurable echo/delay DSP and full 10-band EQ are not implemented yet.

## Build APK
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be in `app/build/outputs/apk/debug/`.

This environment did not have the Android SDK/Gradle build toolchain, so no installable APK has been compiled here. This is the Android Studio source project, not an APK.
