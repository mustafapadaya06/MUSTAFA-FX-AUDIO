package com.mustafa.fxaudio

import android.app.Activity
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var reverb: PresetReverb? = null
    private var virtualizer: Virtualizer? = null
    private var selectedUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private val pickAudio = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xff10131c.toInt()
        window.navigationBarColor = 0xff10131c.toInt()
        buildUi()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 24)
            setBackgroundColor(0xff10131c.toInt())
        }
        fun label(text: String, size: Float = 16f): TextView =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(0xfff2f4ff.toInt()); setPadding(0, 10, 0, 8) }

        page.addView(label("MUSTAFA FX AUDIO", 25f))
        page.addView(label("REVERB  •  ECHO TONE  •  EQ  •  BASS", 12f))
        status = label("Select an audio file to test effects.", 14f)
        page.addView(status)

        val choose = Button(this).apply {
            text = "CHOOSE AUDIO FILE"
            setOnClickListener {
                val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(android.content.Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(intent, pickAudio)
            }
        }
        page.addView(choose)

        playButton = Button(this).apply {
            text = "PLAY"
            isEnabled = false
            setOnClickListener { togglePlayback() }
        }
        page.addView(playButton)
        page.addView(label("PRESETS", 18f))
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Studio", "Hall", "Church", "Cinema").forEachIndexed { i, name ->
            presetRow.addView(Button(this).apply {
                text = name
                setOnClickListener { applyPreset(i) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        page.addView(presetRow)

        page.addView(label("REVERB / ROOM", 18f))
        addSlider(page, "Reverb amount", 0, 100, 35) { value ->
            reverb?.enabled = value > 0
            reverb?.preset = when {
                value < 20 -> PresetReverb.PRESET_NONE
                value < 45 -> PresetReverb.PRESET_SMALLROOM
                value < 70 -> PresetReverb.PRESET_MEDIUMROOM
                else -> PresetReverb.PRESET_LARGEHALL
            }
        }
        page.addView(label("BASS BOOST", 18f))
        addSlider(page, "Bass strength", 0, 1000, 250) { bass?.setStrength(it.toShort()) }
        page.addView(label("3D / STEREO WIDTH", 18f))
        addSlider(page, "Virtualizer strength", 0, 1000, 250) { virtualizer?.setStrength(it.toShort()) }
        page.addView(label("10-BAND EQ (first band prototype)", 18f))
        addSlider(page, "Low frequency gain", 0, 1500, 750) { value ->
            val e = eq ?: return@addSlider
            if (e.numberOfBands > 0) {
                val range = e.bandLevelRange
                val level = (range[0] + (range[1] - range[0]) * value / 1500).toShort()
                e.setBandLevel(0, level)
            }
        }
        page.addView(label("Note: Echo/delay and full 10-band EQ are planned for the next DSP build.", 12f))
        page.addView(label("This prototype processes audio played inside this app. It cannot directly intercept YouTube Music.", 12f))
        val scroll = android.widget.ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun addSlider(parent: LinearLayout, title: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit) {
        val caption = TextView(this).apply { text = "$title: $initial"; textSize = 13f; setTextColor(0xffcbd2e8.toInt()) }
        parent.addView(caption)
        parent.addView(SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + min
                    caption.text = "$title: $value"
                    changed(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickAudio && resultCode == RESULT_OK) {
            selectedUri = data?.data
            status.text = "Audio selected. Press PLAY."
            playButton.isEnabled = selectedUri != null
        }
    }

    private fun togglePlayback() {
        if (player?.isPlaying == true) {
            player?.pause()
            playButton.text = "RESUME"
            return
        }
        if (player != null) {
            player?.start()
            playButton.text = "PAUSE"
            return
        }
        val uri = selectedUri ?: return
        try {
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener {
                    attachEffects(it.audioSessionId)
                    it.start()
                    playButton.text = "PAUSE"
                    status.text = "Playing with MUSTAFA FX effects."
                }
                setOnCompletionListener { playButton.text = "PLAY" }
                prepareAsync()
            }
            status.text = "Loading audio…"
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open this audio file.", Toast.LENGTH_LONG).show()
        }
    }

    private fun attachEffects(sessionId: Int) {
        try {
            eq = Equalizer(0, sessionId).apply { enabled = true }
            bass = BassBoost(0, sessionId).apply { enabled = true; setStrength(250) }
            reverb = PresetReverb(0, sessionId).apply { preset = PresetReverb.PRESET_MEDIUMROOM; enabled = true }
            virtualizer = Virtualizer(0, sessionId).apply { enabled = true; setStrength(250) }
        } catch (_: Exception) {
            status.text = "Audio effects are not supported by this device/player session."
        }
    }

    private fun applyPreset(index: Int) {
        val preset = when (index) {
            0 -> PresetReverb.PRESET_SMALLROOM
            1 -> PresetReverb.PRESET_LARGEHALL
            2 -> PresetReverb.PRESET_PLATE
            else -> PresetReverb.PRESET_MEDIUMROOM
        }
        reverb?.let { it.preset = preset; it.enabled = true }
        val bassLevel = if (index == 3) 400 else 250
        bass?.setStrength(bassLevel.toShort())
        virtualizer?.setStrength((if (index == 2) 550 else 300).toShort())
        Toast.makeText(this, "Preset applied", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { player?.release() } catch (_: Exception) {}
        listOf(eq, bass, reverb, virtualizer).forEach { try { it?.release() } catch (_: Exception) {} }
    }
}
